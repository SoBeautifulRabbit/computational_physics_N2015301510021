# -*- coding: utf-8 -*-
# Created by李东旭 2015301510021
# as assignment for midterm, computational physics

#运行时，有一定概率会运行失败，只要重新试两次就可以了。
#运行本游戏的时候，一定要保证图片和音乐资源在工作目录下
#游戏开始界面，按回车键的速度不要过快，否则程序会停止。
# Have fun playing the game!

#导入必要的包
import pygame
import random
import sys
import math
from pygame.locals import *

#时间和空间常数
WINDOWWIDTH=1024
WINDOWHEIGHT=600
DT=0.02
FPS=50   #要保证DT*FPS=1

#颜色常数
WHITE=(255,255,255)
GOLDEN=(238,199,16)
BLUE=(0,0,255)

#初始金钱
INITIAL_MONEY=80

CHARACTER_SIZE=70
HAMBURGER_SIZE=20
HOUSE_HEIGHT=100
HOUSE_WIDTH=50

#人物速度
CUSTOMER_SPEED=1 
HAMBURGER_SPEED=15
GRAVITY=10

#终止函数
def terminate():
    pygame.quit()
    sys.exit()

#三个绘制文字的函数
def draw_text_white(text,font,surface,x,y):
    text_obj=font.render(text,1,WHITE)
    text_rect=text_obj.get_rect()
    text_rect.topleft=(x,y)
    surface.blit(text_obj,text_rect)
    
def draw_text_golden(text,font,surface,x,y):
    text_obj=font.render(text,1,GOLDEN)
    text_rect=text_obj.get_rect()
    text_rect.topleft=(x,y)
    surface.blit(text_obj,text_rect)
    
def draw_text_blue(text,font,surface,x,y):
    text_obj=font.render(text,1,BLUE)
    text_rect=text_obj.get_rect()
    text_rect.topleft=(x,y)
    surface.blit(text_obj,text_rect)

#两个等待玩家按键的函数    
def wait_for_player_to_press_key1():
    while True:
        for event in pygame.event.get():
            if event.type==QUIT:
                terminate()
            if event.type==KEYDOWN:
                if event.key==K_ESCAPE:
                    terminate()
                if event.key==K_RETURN:
                    return

def wait_for_player_to_press_key2():
    while True:
        for event in pygame.event.get():
            if event.type==QUIT:
                terminate()
            if event.type==KEYDOWN:
                if event.key==K_ESCAPE:
                    terminate()
                if event.key==K_SPACE:
                    return
                
#两种结束游戏的方式
def stolen_recipe():
    window_surface.blit(STOLEN_RECIPE_IMAGE,(0,0))
    draw_text_blue('Your Score:%d'%(score),font,window_surface,300,100)
    pygame.display.update()
    
def no_money():
    window_surface.blit(NO_MONEY_IMAGE,(0,0))
    draw_text_golden('Your Score:%d'%(score),font,window_surface,130,300)
    pygame.display.update()



#六个碰撞函数
def hamburger_hit_customer(hamburgers,customers):
    for h in hamburgers:
        if h['rect'].colliderect(c['rect']):
            hamburgers.remove(h)
            return True
    return False

def hamburger_hit_pilaoban(hamburgers,pilaobans):
    for h in hamburgers:
        if h['rect'].colliderect(p['rect']):
            hamburgers.remove(h)
            return True
    return False

def bomb_hit_customer(bombs,customers):
    for b in bombs:
        if b['rect'].colliderect(c['rect']):
            bombs.remove(b)
            return True
    return False

def bomb_hit_pilaoban(bombs,pilaobans):
    for b in bombs:
        if b['rect'].colliderect(p['rect']):
            bombs.remove(b)
            return True
    return False

def hamburger_hit_house(hamburgers,house):
    for h in hamburgers:
        if h['rect'].colliderect(house['rect']):
            hamburgers.remove(h)
            return True
    return False

def bomb_hit_house(bombs,house):
    for b in bombs:
        if b['rect'].colliderect(house['rect']):
            bombs.remove(b)
            return True
    return False

#游戏初始化
pygame.init()
main_clock=pygame.time.Clock()
window_surface=pygame.display.set_mode((WINDOWWIDTH,WINDOWHEIGHT))
pygame.display.set_caption('SpongeBob')
pygame.mouse.set_visible(True)

#设置字体
font=pygame.font.SysFont(None,48)

#加载图片并勾勒方框
BACKGROUND_IMAGE=pygame.image.load('background.png')
WELCOME_SCREEN=pygame.image.load('welcome.png')
START_SCREEN1=pygame.image.load('start1.png')
START_SCREEN2=pygame.image.load('start2.png')
START_SCREEN3=pygame.image.load('start3.png')
START_SCREEN4=pygame.image.load('start4.png')
CUSTOMER_IMAGE=pygame.image.load('paidaxing.png')
PILAOBAN_IMAGE=pygame.image.load('pilaoban.png')
HAMBURGER_IMAGE=pygame.image.load('hamburger.png')
BOMB_IMAGE=pygame.image.load('bomb.png')
HOUSE_IMAGE=pygame.image.load('house.png')
SPONGEBOB_IMAGE=pygame.image.load('spongebob.png')
STOLEN_RECIPE_IMAGE=pygame.image.load('stolen_recipe.png')
NO_MONEY_IMAGE=pygame.image.load('no_money.png')

customerRect=CUSTOMER_IMAGE.get_rect()
pilaobanRect=PILAOBAN_IMAGE.get_rect()
hamburgerRect=HAMBURGER_IMAGE.get_rect()
bombRect=BOMB_IMAGE.get_rect()
houseRect=HOUSE_IMAGE.get_rect()

#加载音乐
bgm=pygame.mixer.music.load('bgm.mp3')
pygame.mixer.music.play(-1,0.0)

#开始屏幕
window_surface.blit(WELCOME_SCREEN,(0,0))
pygame.display.update()
wait_for_player_to_press_key1()

#游戏规则说明屏幕
window_surface.blit(START_SCREEN1,(0,0))
pygame.display.update()
wait_for_player_to_press_key1()

window_surface.blit(START_SCREEN2,(0,0))
pygame.display.update()
wait_for_player_to_press_key1()

window_surface.blit(START_SCREEN3,(0,0))
pygame.display.update()
wait_for_player_to_press_key1()

window_surface.blit(START_SCREEN4,(0,0))
pygame.display.update()
wait_for_player_to_press_key1()

#主程序
while True:
    customers=[]
    pilaobans=[]
    hamburgers=[]
    bombs=[]
    
    money=INITIAL_MONEY
    score=INITIAL_MONEY
    
    shoot_counter=30
    customer_counter=330
    pilaoban_counter=0
    slower=0
    nandu=0
    
    leixing=True   #True为汉堡，False为炸弹
    shoot=False
    recipe_stolen=False
    
    #建筑物对象
    house={'rect':pygame.Rect(150,WINDOWHEIGHT-160,HOUSE_WIDTH,HOUSE_HEIGHT),'surface':HOUSE_IMAGE}

    while True:#game loop
        for event in pygame.event.get():
            if event.type==QUIT:
                terminate()
                
            if event.type==KEYUP:
                if event.key==K_ESCAPE:
                    terminate()
                if event.key==K_SPACE:
                    shoot=True
                if event.key==K_TAB:
                    if leixing==True:
                        leixing=False
                    else:
                        leixing=True
        
        #增加一个顾客或者痞老板
        if shoot_counter<=25:
            shoot=False
        
        if customer_counter>=300:
            new_customer={'rect':pygame.Rect(WINDOWWIDTH+random.randint(0,200),WINDOWHEIGHT-130,CHARACTER_SIZE,CHARACTER_SIZE),'surface':CUSTOMER_IMAGE}
            customers.append(new_customer)
            customer_counter=0
            
        if pilaoban_counter>=1000-nandu:
            new_pilaoban={'rect':pygame.Rect(WINDOWWIDTH+random.randint(0,200),WINDOWHEIGHT-130,CHARACTER_SIZE,CHARACTER_SIZE),'surface':PILAOBAN_IMAGE}
            pilaobans.append(new_pilaoban)
            pilaoban_counter=0
            
        #增加一个蟹黄包或者炸弹
        if shoot==True and leixing==True:   #此时是汉堡
            pos=pygame.mouse.get_pos()
            mouse_x=pos[0]
            mouse_y=pos[1]
            delta_x=mouse_x-50
            delta_y=WINDOWHEIGHT-50-mouse_y
            delta_l=math.sqrt(delta_x**2+delta_y**2)
            v_x=HAMBURGER_SPEED*delta_x/delta_l
            v_y=-HAMBURGER_SPEED*delta_y/delta_l
            
            new_hamburger={'rect':pygame.Rect(50,WINDOWHEIGHT-80,HAMBURGER_SIZE,HAMBURGER_SIZE),'surface':HAMBURGER_IMAGE,'v_x':v_x,'v_y':v_y}
            hamburgers.append(new_hamburger)
            
            shoot==False
            shoot_counter=0
            money=money-4
            
        if shoot==True and leixing==False:   #此时是炸弹
            pos=pygame.mouse.get_pos()
            mouse_x=pos[0]
            mouse_y=pos[1]
            delta_x=mouse_x-50
            delta_y=WINDOWHEIGHT-50-mouse_y
            delta_l=math.sqrt(delta_x**2+delta_y**2)
            v_x=HAMBURGER_SPEED*delta_x/delta_l
            v_y=-HAMBURGER_SPEED*delta_y/delta_l
            
            new_bomb={'rect':pygame.Rect(50,WINDOWHEIGHT-50,HAMBURGER_SIZE,HAMBURGER_SIZE),'surface':BOMB_IMAGE,'v_x':v_x,'v_y':v_y}
            bombs.append(new_bomb)
            
            shoot==False
            shoot_counter=0
            money=money-10
            
        #move the customers and pilaobans
        if slower>=2:              #让顾客和痞老板运动的速度更慢
            for c in customers:
                c['rect'].move_ip(-2*CUSTOMER_SPEED,0)
            for p in pilaobans:
                p['rect'].move_ip(-1*CUSTOMER_SPEED,0)
            slower=0
        else:
            slower=slower+1
            
        #move the hamburgers and bombs
        for h in hamburgers:
            h['rect'].move_ip(h['v_x'],h['v_y'])  
            h['v_y']=h['v_y']+GRAVITY*DT

        for b in bombs:
            b['rect'].move_ip(b['v_x'],b['v_y'])
            b['v_y']=b['v_y']+GRAVITY*DT
        
        #计数器
        shoot_counter=shoot_counter+1
        customer_counter=customer_counter+1
        pilaoban_counter=pilaoban_counter+1
        nandu=nandu+0.1
        
        #计分
        if score<money:
            score=money
            
        #没钱的时候终止游戏    
        if money<=-1:
            no_money()
            break
        
        #删除超出边界的元素
        for h in hamburgers:
            if h['rect'].bottom>WINDOWHEIGHT:
                hamburgers.remove(h)
        
        for b in bombs:
            if b['rect'].bottom>WINDOWHEIGHT:
                bombs.remove(b)
        
        for c in customers:
            if c['rect'].left<200:
                customers.remove(c)
                
        for p in pilaobans:
            if p['rect'].left<200:
                stolen_recipe()
        
        #检查是否产生碰撞
        for c in customers:
            if hamburger_hit_customer(hamburgers,customers):
                money=money+15
                customers.remove(c)
        for c in customers:
            if bomb_hit_customer(bombs,customers):
                customers.remove(c)
        for p in pilaobans:
            if hamburger_hit_pilaoban(hamburgers,pilaobans):
                recipe_stolen=True   
        #蟹黄堡秘方被偷了之后终止游戏
        if recipe_stolen==True:
            stolen_recipe()
            break
        for p in pilaobans:
            if bomb_hit_pilaoban(bombs,pilaobans):
                pilaobans.remove(p)
        
        hamburger_hit_house(hamburgers,house) #汉堡撞上建筑物就会消失
        bomb_hit_house(bombs,house)
            
                
        #绘制图形
        window_surface.blit(BACKGROUND_IMAGE,(0,0))
        window_surface.blit(house['surface'],house['rect'])
        window_surface.blit(SPONGEBOB_IMAGE,(20,WINDOWHEIGHT-180))
        
        for h in hamburgers:
            window_surface.blit(h['surface'],h['rect'])
        for b in bombs:
            window_surface.blit(b['surface'],b['rect'])
        for c in customers:
            window_surface.blit(c['surface'],c['rect'])
        for p in pilaobans:
            window_surface.blit(p['surface'],p['rect'])
        
        draw_text_white('score:%d'%(score),font,window_surface,WINDOWWIDTH-200,50)
        draw_text_golden('money:$%d'%(money),font,window_surface,WINDOWWIDTH-200,150)
        if leixing==True:
            draw_text_white('Hamburger',font,window_surface,WINDOWWIDTH-200,100)
            window_surface.blit(HAMBURGER_IMAGE,(WINDOWWIDTH-245,100))
        else:
            draw_text_white('Bomb',font,window_surface,WINDOWWIDTH-200,100)
            window_surface.blit(BOMB_IMAGE,(WINDOWWIDTH-245,100))
   
        pygame.display.update()
        main_clock.tick(FPS)
    wait_for_player_to_press_key2()




            
            
            
        
        
        